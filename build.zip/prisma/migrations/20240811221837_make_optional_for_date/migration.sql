-- AlterTable
ALTER TABLE `appointmentinfo` MODIFY `date` DATETIME(3) NULL;
