-- DropIndex
DROP INDEX `User_forgotPasswordToken_key` ON `user`;
