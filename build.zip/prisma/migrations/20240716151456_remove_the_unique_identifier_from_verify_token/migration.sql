-- DropIndex
DROP INDEX `User_verifyToken_key` ON `user`;
