// next.config.mjs
export default {
  images: {
    domains: ["api.dicebear.com"], // Add any other domains you need
  },
  // Other configurations...
};
