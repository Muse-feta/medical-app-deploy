/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["api.dicebear.com"], // Add any other domains you need
  },
  // Other configurations...
};

export default nextConfig;
