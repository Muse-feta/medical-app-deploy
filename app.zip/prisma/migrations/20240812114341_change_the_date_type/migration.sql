-- AlterTable
ALTER TABLE `appointmentinfo` MODIFY `date` VARCHAR(191) NULL;
